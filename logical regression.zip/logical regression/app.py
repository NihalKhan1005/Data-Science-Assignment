import pandas as pd
import joblib
import streamlit as st
# Load the trained model
model = joblib.load(r"C:\Users\NIHAL_MIRAJ\Desktop\logistic_regression_model.pkl")

# Streamlit user inputs
st.title('Titanic Survival Prediction')
st.sidebar.header('User Input Features')

def user_input_features():
    # Collect user inputs for each feature
    age = st.sidebar.slider('Age', 0, 100, 30)
    sex = st.sidebar.selectbox('Sex', ['male', 'female'])
    pclass = st.sidebar.selectbox('Pclass', [1, 2, 3])
    sibsp = st.sidebar.slider('SibSp', 0, 10, 0)
    parch = st.sidebar.slider('Parch', 0, 10, 0)
    fare = st.sidebar.slider('Fare', 0, 500, 30)
    embarked = st.sidebar.selectbox('Embarked', ['C', 'Q', 'S'])  # Embarked options
    
    # Encode categorical features
    sex_male = 1 if sex == 'male' else 0
    embarked_C = 1 if embarked == 'C' else 0
    embarked_Q = 1 if embarked == 'Q' else 0
    
    # Prepare input data as a DataFrame
    features = pd.DataFrame(
        {'Age': [age],
         'SibSp': [sibsp],
         'Parch': [parch],
         'Fare': [fare],
         'Sex_male': [sex_male],
         'Embarked_C': [embarked_C],
         'Embarked_Q': [embarked_Q],
         'Pclass': [pclass]})
    
    # Ensure the columns match the training data
    # Check for any missing columns from training and add them as needed
    missing_cols = set(model.feature_names_in_) - set(features.columns)
    for col in missing_cols:
        features[col] = 0  # Set missing columns to 0 (or the default value)

    # Ensure columns are in the same order as during training
    features = features[model.feature_names_in_]
    
    return features

# Get user input
input_data = user_input_features()

# Display the user input data
st.subheader('User Input:')
st.write(input_data)

# Predict using the model
prediction = model.predict(input_data)
prediction_proba = model.predict_proba(input_data)

# Display the prediction result
st.subheader('Prediction Result:')
if prediction == 1:
    st.write("The person survived!")
else:
    st.write("The person did not survive.")

# Display the probability of survival
st.subheader('Prediction Probability:')
st.write(f"Survival Probability: {prediction_proba[0][1] * 100:.2f}%")
st.write(f"Death Probability: {prediction_proba[0][0] * 100:.2f}%")
